# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
# This script is a quick way of making a merger composition
# 
# Ylva Götberg, 5 August, 2021
#
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

import numpy as np

# Where are the last profiles of the stars in the binary?
loc_binary = './'
filename_M1 = loc_binary+'M1_last_profile.data'
filename_M2 = loc_binary+'M2_last_profile.data'

# Read the header
fid = open(filename_M1,'r')
header = fid.readlines()[5].split()
fid.close()

# Read the data
data1 = np.loadtxt(filename_M1,skiprows=6)
data2 = np.loadtxt(filename_M2,skiprows=6)

# Concatenate the data
data_tot = np.concatenate([data1,data2])

# Sort by entropy - index creation
entropy_tot = data_tot[:,header.index('entropy')]
ind_sort = np.argsort(entropy_tot)

# Sort the entire data matrix
data_tot_sorted = data_tot[ind_sort,:]

# Calculate xq => the fraction of mass outside each cell
dm = data_tot_sorted[:,header.index('dm')]/(1.989e33)    # Converting from gram to solar masses
Mtot = np.sum(dm)
m_outside = np.cumsum(dm[::-1])[::-1]-dm
xq = m_outside/Mtot
#print('Total mass of merger product:', Mtot, 'Msun')
#print('This is assuming no mass is lost.')

# Get the composition - note that this is for the basic net!
h1 = data_tot_sorted[:,header.index('h1')]
he3 = data_tot_sorted[:,header.index('he3')]
he4 = data_tot_sorted[:,header.index('he4')]
c12 = data_tot_sorted[:,header.index('c12')]
n14 = data_tot_sorted[:,header.index('n14')]
o16 = data_tot_sorted[:,header.index('o16')]
ne20 = data_tot_sorted[:,header.index('ne20')]
mg24 = data_tot_sorted[:,header.index('mg24')]

isotopes = [h1,he3,he4,c12,n14,o16,ne20,mg24]

# Write the composition file

# first: nbr of zones, nbr of isotopes
# second each zone, starting from surface going in, give xq and mass fraction of each element

fid = open(loc_binary+'merger_composition.txt','w')
fid.write(str(len(xq))+'\t'+str(len(isotopes))+'\n')

for i in range(len(xq)-1,-1,-1):
    write_str = str(xq[i])
    for j in range(len(isotopes)):
        write_str = write_str+'\t'+str(isotopes[j][i])
    fid.write(write_str+'\n')

fid.close()
